<?php 
session_start();
include('conexao.php');

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: painelAdmin.php?erro=acesso");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: painelAdmin.php?erro=sem_id");
    exit();
}

$id_produto = (int)$_GET['id'];

// Exclui os itens relacionados
$stmt1 = $conn->prepare("DELETE FROM item_venda WHERE id_produto = ?");
$stmt1->bind_param("i", $id_produto);
$stmt1->execute();
$stmt1->close();

// Exclui o produto
$stmt2 = $conn->prepare("DELETE FROM produto WHERE id_produto = ?");
$stmt2->bind_param("i", $id_produto);
$stmt2->execute();
$stmt2->close();

$conn->close();

// Redireciona de volta com uma flag de sucesso
header("Location: painelAdmin.php?excluido=1");
exit();
?>

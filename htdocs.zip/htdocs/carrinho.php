<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Buscar venda com status 'carrinho'
$stmt = $conn->prepare("SELECT id_venda FROM venda WHERE id_cliente = ? AND status = 'carrinho' ORDER BY id_venda DESC LIMIT 1");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

$id_venda = null;
$carrinho_vazio = true;

if ($result->num_rows > 0) {
    $venda = $result->fetch_assoc();
    $id_venda = $venda['id_venda'];
    $carrinho_vazio = false;
}

// Ações via POST (quantidade ou remoção)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$carrinho_vazio) {
    $item_id = $_POST['item_id'];

    if (isset($_POST['aumentar'])) {
        $conn->query("UPDATE item_venda SET item_quantidade = item_quantidade + 1 WHERE id_item_venda = $item_id AND id_venda = $id_venda");
    } elseif (isset($_POST['diminuir'])) {
        $conn->query("UPDATE item_venda SET item_quantidade = item_quantidade - 1 WHERE id_item_venda = $item_id AND id_venda = $id_venda AND item_quantidade > 1");
    } elseif (isset($_POST['remover'])) {
        $conn->query("DELETE FROM item_venda WHERE id_item_venda = $item_id AND id_venda = $id_venda");
    }

    header("Location: carrinho.php");
    exit();
}

// Ações via GET (finalizar ou limpar)
if (!$carrinho_vazio && isset($_GET['finalizar'])) {
    $sql = "SELECT iv.id_item_venda, iv.id_produto, iv.item_quantidade, iv.item_valor, p.id_loja
            FROM item_venda iv
            JOIN produto p ON iv.id_produto = p.id_produto
            WHERE iv.id_venda = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_venda);
    $stmt->execute();
    $result = $stmt->get_result();

    $itens_por_loja = [];
    while ($item = $result->fetch_assoc()) {
        $id_loja_item = $item['id_loja'];
        $itens_por_loja[$id_loja_item][] = $item;
    }

    foreach ($itens_por_loja as $id_loja_atual => $itens) {
        $total_venda = 0;

        foreach ($itens as $item) {
            $total_venda += $item['item_quantidade'] * $item['item_valor'];
        }

        $stmt = $conn->prepare("INSERT INTO venda (total, data, id_cliente, id_loja, status) VALUES (?, NOW(), ?, ?, 'finalizada')");
        $stmt->bind_param("dii", $total_venda, $usuario_id, $id_loja_atual);
        $stmt->execute();
        $nova_id_venda = $stmt->insert_id;

        foreach ($itens as $item) {
            // Atualiza item para nova venda finalizada
            $stmt = $conn->prepare("UPDATE item_venda SET id_venda = ? WHERE id_item_venda = ?");
            $stmt->bind_param("ii", $nova_id_venda, $item['id_item_venda']);
            $stmt->execute();

            // Buscar os dados completos do produto, loja e vendedor
            $sql_detalhes = "SELECT p.nome AS nome_produto, p.descricao, p.imagem, p.preco,
                l.nome AS nome_loja, l.endereco, l.telefone, l.cnpj, l.cpf,
                v.nome AS nome_vendedor, v.email AS email_vendedor
                FROM produto p
                JOIN loja l ON p.id_loja = l.id_loja
                JOIN vendedor v ON l.id_loja = v.id_loja
                WHERE p.id_produto = ?";
            $stmt_detalhes = $conn->prepare($sql_detalhes);
            $stmt_detalhes->bind_param("i", $item['id_produto']);
            $stmt_detalhes->execute();
            $detalhes = $stmt_detalhes->get_result()->fetch_assoc();

            // Inserir os dados na tabela nota_fiscal
            $sql_nota = "INSERT INTO nota_fiscal (
                id_venda, nome_produto, descricao, imagem, preco_unitario, quantidade,
                nome_loja, endereco_loja, telefone_loja, cnpj_loja, cpf_loja,
                nome_vendedor, email_vendedor, data_registro
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

            $stmt_nota = $conn->prepare($sql_nota);
            $stmt_nota->bind_param(
                "isssdisssssss",
                $nova_id_venda,
                $detalhes['nome_produto'],
                $detalhes['descricao'],
                $detalhes['imagem'],
                $detalhes['preco'],
                $item['item_quantidade'],
                $detalhes['nome_loja'],
                $detalhes['endereco'],
                $detalhes['telefone'],
                $detalhes['cnpj'],
                $detalhes['cpf'],
                $detalhes['nome_vendedor'],
                $detalhes['email_vendedor']
            );
            $stmt_nota->execute();
        }
    }

    // Deleta a venda temporária com status 'carrinho'
    $conn->query("DELETE FROM venda WHERE id_venda = $id_venda");

    header("Location: telaprodutos.php");
    exit();
}

if (!$carrinho_vazio && isset($_GET['limpar'])) {
    $conn->query("DELETE FROM item_venda WHERE id_venda = $id_venda");
    header("Location: carrinho.php");
    exit();
}

// Buscar itens no carrinho (se houver)
$itens = [];
$total = 0;

if (!$carrinho_vazio) {
    $sql = "SELECT iv.id_item_venda, p.nome, p.descricao, p.imagem, iv.item_quantidade, iv.item_valor, l.nome AS nome_loja, v.nome AS nome_vendedor 
            FROM item_venda iv 
            JOIN produto p ON iv.id_produto = p.id_produto 
            JOIN loja l ON p.id_loja = l.id_loja
            JOIN vendedor v ON l.id_loja = v.id_loja
            WHERE iv.id_venda = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_venda);
    $stmt->execute();
    $itens = $stmt->get_result();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Carrinho de Compras</title>
    <link rel="stylesheet" href="css/carrinho.css">
    <style>
        .btn-remover {
            margin-top: 10px;
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 4px;
        }
        .btn-remover:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo"><img src="../images/site2.png" alt="Logo" style="width: 4.7rem;"></div>
        <div class="search-bar">
            <input type="text" placeholder="Buscar produtos..." id="search-input">
        </div>

        <div class="titulo-carrinho">
            <h2>Seu Carrinho</h2>
            <a href="telaprodutos.php" class="btn-voltar">
                <img src="images/voltar.png" alt="Voltar">
            </a>
        </div>
    </header>

    <?php if (isset($_SESSION['msg'])): ?>
        <div class="msg"><?= $_SESSION['msg']; unset($_SESSION['msg']); ?></div>
    <?php endif; ?>

    <section>
        <?php if ($carrinho_vazio || $itens->num_rows === 0): ?>
            <p style="color: #555; text-align:center; margin-top: 2rem; font-weight: bold">Nenhum produto adicionado no carrinho.</p>
        <?php else: ?>
            <div class="carrinho">
                <?php while ($item = $itens->fetch_assoc()):
                    $subtotal = $item['item_valor'] * $item['item_quantidade'];
                    $total += $subtotal;
                ?>
                <div class="product-card">
                    <img src="uploads/<?= htmlspecialchars($item['imagem']); ?>" alt="<?= htmlspecialchars($item['nome']); ?>">
                    <div class="product-details">
                        <h3 class="product-name"><?= htmlspecialchars($item['nome']); ?></h3>
                        <p class="product-description"><?= htmlspecialchars($item['descricao']); ?></p>
                        <p class="product-description">Loja: <?= htmlspecialchars($item['nome_loja']); ?></p>
                        <p class="product-description">Vendedor: <?= htmlspecialchars($item['nome_vendedor']); ?></p>
                        <div class="price-info" style="margin-top: 10px;">
                            <p><strong>Preço unitário:</strong> R$ <?= number_format($item['item_valor'], 2, ',', '.') ?></p>
                        </div>

                        <div class="quantidade-container">
                            <p><strong>Quantidade:</strong></p>
                            <div class="quantidade-controls">
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="item_id" value="<?= $item['id_item_venda']; ?>">
                                    <button type="submit" name="diminuir" <?= $item['item_quantidade'] <= 1 ? 'disabled' : ''; ?>>−</button>
                                </form>
                                <span class="quantidade"><?= $item['item_quantidade']; ?></span>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="item_id" value="<?= $item['id_item_venda']; ?>">
                                    <button type="submit" name="aumentar">+</button>
                                </form>
                            </div>
                        </div>

                        <div class="subtotal-remover">
                            <p class="subtotale">
                                <strong>Subtotal:</strong> R$ <?= number_format($subtotal, 2, ',', '.') ?>
                            </p>
                            <form method="post" onsubmit="return confirm('Tem certeza que deseja remover este produto do carrinho?');">
                                <input type="hidden" name="item_id" value="<?= $item['id_item_venda']; ?>">
                                <button type="submit" name="remover" class="remove-cart-button">
                                    <img src="images/lixeira.png" alt="Remover do Carrinho">
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <p class="total">Total: R$ <?= number_format($total, 2, ',', '.'); ?></p>
            <div class="botoes">
                <a class="btn" href="?finalizar=true" onclick="return confirmarFinalizacao()">Finalizar Compra</a>
                <a class="btn btn-clear" href="?limpar=true">Limpar Carrinho</a>
            </div>
        <?php endif; ?>
    </section>

    <script>
        // Limpa a flag sempre que a página do carrinho é carregada
        window.onload = function () {
            sessionStorage.removeItem('avisoFinalizacaoMostrado');
        };

        function confirmarFinalizacao() {
            if (!sessionStorage.getItem('avisoFinalizacaoMostrado')) {
                alert("Antes de finalizar a compra, combine a forma de entrega com o vendedor entrando em contato com ele.");
                sessionStorage.setItem('avisoFinalizacaoMostrado', 'true');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>

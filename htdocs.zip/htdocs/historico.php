<?php
session_start();
include('conexao.php');

// Verifica se o usuário está logado
if (!isset($_SESSION['id_cliente'])) {
    echo "Você precisa estar logado para ver seu histórico.";
    exit();
}

$id_cliente = $_SESSION['id_cliente'];

// Busca as vendas finalizadas desse cliente
$sqlVendas = "
SELECT id_venda, data
FROM venda
WHERE id_cliente = ? AND status = 'finalizado'
ORDER BY data DESC
";
$stmtVendas = $conn->prepare($sqlVendas);
$stmtVendas->bind_param("i", $id_cliente);
$stmtVendas->execute();
$resultVendas = $stmtVendas->get_result();

echo "<h2>Seu Histórico de Compras</h2>";

if ($resultVendas->num_rows === 0) {
    echo "<p>Você ainda não finalizou nenhuma compra.</p>";
} else {
    while ($venda = $resultVendas->fetch_assoc()) {
        $id_venda = $venda['id_venda'];
        echo "<hr>";
        echo "<h3>Pedido #{$id_venda} - Data: " . $venda['data'] . "</h3>";

        // Busca os itens da venda
        $sqlItens = "
        SELECT p.nome, p.preco, i.quantidade, (p.preco * i.quantidade) AS subtotal
        FROM item_venda i
        JOIN produto p ON i.id_produto = p.id
        WHERE i.id_venda = ?
        ";
        $stmtItens = $conn->prepare($sqlItens);
        $stmtItens->bind_param("i", $id_venda);
        $stmtItens->execute();
        $resultItens = $stmtItens->get_result();

        $total = 0;
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Subtotal</th></tr>";
        while ($item = $resultItens->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($item['nome']) . "</td>
                    <td>R$ " . number_format($item['preco'], 2, ',', '.') . "</td>
                    <td>" . $item['quantidade'] . "</td>
                    <td>R$ " . number_format($item['subtotal'], 2, ',', '.') . "</td>
                  </tr>";
            $total += $item['subtotal'];
        }
        echo "<tr><td colspan='3'><strong>Total</strong></td><td><strong>R$ " . number_format($total, 2, ',', '.') . "</strong></td></tr>";
        echo "</table>";
    }
}
?>

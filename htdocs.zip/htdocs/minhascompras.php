<?php
session_start();

// Verifica se o usuário está logado como "cliente"
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    header("Location: login.php");
    exit();
}

$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Funções auxiliares
function formatar_telefone_exibicao($telefone) {
    $telefone = preg_replace('/\D/', '', $telefone);
    return (strlen($telefone) == 11)
        ? '(' . substr($telefone, 0, 2) . ') ' . substr($telefone, 2, 5) . '-' . substr($telefone, 7)
        : $telefone;
}

function formatar_telefone_whatsapp($telefone) {
    $telefone = preg_replace('/\D/', '', $telefone);
    return (substr($telefone, 0, 2) != '55') ? '55' . $telefone : $telefone;
}

function formatar_cpf($cpf) {
    $cpf = preg_replace('/\D/', '', $cpf);
    return (strlen($cpf) == 11)
        ? substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2)
        : $cpf;
}

function formatar_cnpj($cnpj) {
    $cnpj = preg_replace('/\D/', '', $cnpj);
    return (strlen($cnpj) == 14)
        ? substr($cnpj, 0, 2) . '.' . substr($cnpj, 2, 3) . '.' . substr($cnpj, 5, 3) . '/' . substr($cnpj, 8, 4) . '-' . substr($cnpj, 12, 2)
        : $cnpj;
}

// Obter o ID do cliente logado
$usuario_id = $_SESSION['usuario_id'];

// Buscar os dados da nota fiscal das compras finalizadas
$sql = "SELECT 
            nf.id_venda,
            nf.nome_produto,
            nf.descricao,
            nf.imagem,
            nf.preco_unitario AS item_valor,
            nf.quantidade AS item_quantidade,
            nf.nome_loja,
            nf.endereco_loja,
            nf.telefone_loja,
            nf.cnpj_loja,
            nf.cpf_loja,
            nf.nome_vendedor,
            nf.email_vendedor,
            v.data AS data_venda
        FROM nota_fiscal nf
        JOIN venda v ON nf.id_venda = v.id_venda
        WHERE v.id_cliente = ?
        ORDER BY v.data DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

$compras = [];
while ($row = $result->fetch_assoc()) {
    $compras[] = $row;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Minhas Compras - Marketplace</title>
    <link rel="stylesheet" href="css/minhascompras.css">
</head>
<body>

<header>
    <div class="logo">
        <img src="images/site2.png" alt="Logo" style="width: 4.7rem;">
    </div>

    <div class="search-bar">
        <input type="text" placeholder="Buscar produtos..." id="search-input">
    </div>

    <div class="titulo-carrinho">
        <h2>Minhas Compras</h2>
        <a href="../php/site.php" class="btn-voltar">
            <img src="images/voltar.png" alt="Voltar">
        </a>
    </div>
</header>

<section class="compras-list">
    <?php if (count($compras) > 0): ?>
        <?php foreach ($compras as $compra): ?>
            <div class="compra-card">
                <img src="uploads/<?php echo htmlspecialchars($compra['imagem']); ?>" alt="<?php echo htmlspecialchars($compra['nome_produto']); ?>" class="compra-img">
                <div class="compra-details">
                    <h3 class="compra-nome"><?php echo htmlspecialchars($compra['nome_produto']); ?></h3>
                    <p class="compra-loja">Loja: <?php echo htmlspecialchars($compra['nome_loja']); ?></p>
                    <p class="compra-vendedor">Vendedor: <?php echo htmlspecialchars($compra['nome_vendedor']); ?></p>
                    <p class="compra-email">Email: <?php echo htmlspecialchars($compra['email_vendedor']); ?></p>
                    <p class="compra-endereco">Endereço: <?php echo htmlspecialchars($compra['endereco_loja']); ?></p>
                    
                    <?php 
                    $telefone_formatado = formatar_telefone_exibicao($compra['telefone_loja']);
                    $telefone_whatsapp = formatar_telefone_whatsapp($compra['telefone_loja']);
                    $cnpj_formatado = formatar_cnpj($compra['cnpj_loja']);
                    $cpf_formatado = formatar_cpf($compra['cpf_loja']);
                    ?>

                    <p class="compra-telefone">Telefone: <?php echo $telefone_formatado; ?></p>
                    <p class="compra-cnpj-cpf">
                        <strong>
                            <?php 
                                echo !empty($compra['cnpj_loja']) ? 'CNPJ: ' . $cnpj_formatado : 'CPF: ' . $cpf_formatado;
                            ?>
                        </strong>
                    </p>
                    <p class="compra-quantidade">Quantidade: <?php echo $compra['item_quantidade']; ?></p>
                    <p class="compra-preco">Preço unitário: R$ <?php echo number_format($compra['item_valor'], 2, ',', '.'); ?></p>
                    <p class="compra-total">Total: R$ <?php echo number_format($compra['item_valor'] * $compra['item_quantidade'], 2, ',', '.'); ?></p>
                    <p class="compra-data">Data da compra: <?php echo date('d/m/Y', strtotime($compra['data_venda'])); ?></p>
                    
                    <div class="button-group">
                        <a href="https://wa.me/<?php echo $telefone_whatsapp; ?>" class="contact-button" target="_blank">Contato com o Vendedor</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhuma compra realizada ainda.</p>
    <?php endif; ?>
</section>

<footer>
    <div class="footer-links">
        <a href="/sobre">Sobre</a>
        <a href="/politica-privacidade">Política de Privacidade</a>
        <a href="/termos-uso">Termos de Uso</a>
    </div>
    <div class="footer-info">
        <p>© 2025 TaquaMarket. Todos os direitos reservados.</p>
    </div>
</footer>

</body>
</html>

<?php $conn->close(); ?>




<?php
  $idproduto= $_GET['produto'];
  echo $idproduto;


?>
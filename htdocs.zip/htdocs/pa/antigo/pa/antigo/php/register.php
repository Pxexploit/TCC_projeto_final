<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); 

    // Verificar se o email já está registrado
    $sql_check = "SELECT id FROM usuarios WHERE email = '$email'";
    $result = $conn->query($sql_check);

    if ($result->num_rows > 0) {
        echo "Este email já está registrado!";
    } else {

        $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";

        if ($conn->query($sql) === TRUE) {
            // cod para a página de login após o cadastro
            header("Location: ../login.php");
            exit; 
        } else {
            echo "Erro ao cadastrar usuário: " . $conn->error;
        }
    }
}

$conn->close();
?>

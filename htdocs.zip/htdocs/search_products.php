<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$MIN_PRICE_ALLOWED = 0;
$MAX_PRICE_ALLOWED = 9999999999.99;

function sanitize_price($price, $min, $max) {
    if (!is_numeric($price)) return $min;
    $price = floatval($price);
    if ($price < $min) return $min;
    if ($price > $max) return $max;
    return $price;
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$minPrice = isset($_GET['min-price']) ? sanitize_price($_GET['min-price'], $MIN_PRICE_ALLOWED, $MAX_PRICE_ALLOWED) : $MIN_PRICE_ALLOWED;
$maxPrice = isset($_GET['max-price']) ? sanitize_price($_GET['max-price'], $MIN_PRICE_ALLOWED, $MAX_PRICE_ALLOWED) : $MAX_PRICE_ALLOWED;

if ($minPrice > $maxPrice) {
    $maxPrice = $minPrice;
}

$sql = "SELECT 
            produto.id_produto,
            produto.nome AS nome_produto, 
            produto.descricao, 
            produto.preco, 
            produto.imagem,  
            loja.nome AS nome_loja, 
            vendedor.nome AS nome_vendedor, 
            vendedor.email,
            loja.telefone
        FROM produto 
        INNER JOIN loja ON produto.id_loja = loja.id_loja
        INNER JOIN vendedor ON vendedor.id_loja = loja.id_loja
        WHERE produto.preco BETWEEN ? AND ?";

if (!empty($search)) {
    $sql .= " AND produto.nome LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = '%' . $search . '%';
    $stmt->bind_param("dds", $minPrice, $maxPrice, $searchTerm);
} else {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dd", $minPrice, $maxPrice);
}

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($produto = $result->fetch_assoc()) {
        ?>
        <div class="product-card">
            <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome_produto']); ?>">
            <div class="product-details">
                <h3 class="product-name"><?php echo htmlspecialchars($produto['nome_produto']); ?></h3>
                <p class="product-description"><?php echo htmlspecialchars($produto['descricao']); ?></p>
                <span class="product-price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></span><br>
                <span class="product-store">Loja: <?php echo htmlspecialchars($produto['nome_loja']); ?></span><br>
                <span class="product-seller">Vendedor: <?php echo htmlspecialchars($produto['nome_vendedor']); ?></span>

                <div class="button-group">
                    <a href="https://wa.me/<?php echo preg_replace('/\D/', '', $produto['telefone']); ?>" class="contact-button" target="_blank">
                        Contato via WhatsApp
                    </a>
                    <a href="?produto=<?php echo $produto['id_produto']; ?>" class="add-cart-button">
                        <img src="images/addcarrinho.png" alt="Adicionar ao Carrinho" style="width: 2rem;">
                    </a>
                </div>
            </div>
        </div>
        <?php
    }
} else {
    echo "<p>Nenhum produto encontrado.</p>";
}

$conn->close();
?>
